var canvas = document.createElement("canvas");
canvas.width = "600";
canvas.height = "600";

var ctx = canvas.getContext('2d');
document.body.insertBefore(canvas, document.body.childNodes[0]);
  
// Variables
var width = canvas.width,
    height = canvas.height;
var fps = 0;

// Shapes
function circle(x, y, radius) {
  ctx.arc(x, y, radius, 0, Math.PI * 2)
}
function rect(x, y, w, h) {
  ctx.fillRect(x, y, w, h);
}
function tri(x1, y1, x2, y2, x3, y3) {
  ctx.beginPath();
    ctx.lineTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(x3, y3);
  ctx.closePath();
}
  
// Coloring
function fill(r, g, b) {
  ctx.fillStyle = "rgb("+r+", "+g+", "+b+")";
}
function background(){
  ctx.clearRect(0, 0, width, height);
}

// Text
function textSize(size) {
  ctx.font = size + "px arial";
}
function text(message, x, y) {
  ctx.fillText(message, x, y);
}

// Images
function image(img, x, y, w, h) {
  var IMG = new Image(w, h);
  IMG.src = img;
  ctx.drawImage(IMG, x, y, IMG.width, IMG.height);
}

// FPS
function drawFPS(){
  text(fps, 20, 30);
}

